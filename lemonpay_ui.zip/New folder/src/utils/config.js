export const config = {
    tools: {
        basURL:'http://localhost:5000/api/'  
    }
}